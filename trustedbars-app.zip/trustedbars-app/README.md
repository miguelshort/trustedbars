# TrustedBars · Sevilla y alrededores

App móvil web (HTML + JS sin dependencias) para decidir dónde cenar barato y sin cola, solo en Sevilla y alrededores
(Dos Hermanas, Alcalá de Guadaíra, Mairena del Aljarafe, Camas…).

## Ejecutar
Abre `index.html` en el navegador (o sirve la carpeta: `npx serve .`). Funciona sin servidor ni claves en modo Demostración.

## Qué hace
- Filtros: **Cuándo** (entre semana / fin de semana), **Por persona**, **Somos**, **Espera**, **Más filtros** (minutos a pie, poca gente).
- Ordena por valoración ponderada por nº de reseñas, tiempo hasta sentarse, margen sobre el presupuesto, tamaño de grupo cómodo
  y **afluencia habitual** del tipo de día elegido.
- Barra inferior en cápsula y desplegables con efecto cristal (`backdrop-filter`).
- **Cómo llegar** abre Google Maps a pie; sin `origin`, Google usa la ubicación actual del usuario. «Desde la salida elegida» fija el origen.

## Conexión con Google Places
1. Activa **Places API (New)** en Google Cloud y crea una clave. Restríngela por referente HTTP y por API.
2. En la app: botón ⓘ → «Conexión con Google Places» → pega la clave → «Actualizar bares desde Google».
   Trae bares y restaurantes a 1,5 km de la zona de salida y los guarda en el navegador.
3. Análisis previo (recomendado): `GOOGLE_MAPS_API_KEY=... node tools/analyze.mjs` recorre las 12 zonas, filtra
   (≥3,8 ★ y ≥30 reseñas) y reescribe `data/bars.js` con el análisis ya hecho.

## Límites que conviene conocer
- Google **no** da horas punta ni cola por API. La afluencia habitual se **estima** (`js/analysis.js`) desde nº de reseñas,
  valoración y tipo de día; la app lo marca como estimación. La espera real saldrá de avisos de locales y clientes (aún sin backend).
- Precio: se usa `priceRange` de Google. Sin él, solo hay nivel de precio y el bar **no cuenta** para un presupuesto concreto.
  El precio de fin de semana es un supuesto (+8 %), ajustable en `WEEKEND_PRICE_FACTOR`.
- El horario de cocina se aproxima con el horario de apertura de Google (miércoles = entre semana, sábado = fin de semana).
- Los bares de `data/bars.js` por defecto son **ficticios** (demostración). No se ha probado contra la API real de Google en esta entrega.
