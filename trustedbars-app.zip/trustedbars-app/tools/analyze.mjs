// Análisis previo: descarga bares/restaurantes públicos de Sevilla y alrededores desde Google Places (API New),
// calcula precio por tipo de día, afluencia habitual estimada y horario de cocina, y escribe data/bars.js.
// Uso:  GOOGLE_MAPS_API_KEY=tu_clave node tools/analyze.mjs   (Node 18+)
import { createRequire } from 'node:module';
import { writeFileSync } from 'node:fs';
const require = createRequire(import.meta.url);
const A = require('../js/analysis.js');
const KEY = process.env.GOOGLE_MAPS_API_KEY;
if (!KEY) { console.error('Falta GOOGLE_MAPS_API_KEY'); process.exit(1); }

const ZONES = [ // [nombre, lat, lng, radio m]
  ['Plaza de la Alfalfa', 37.3933, -5.9906, 900], ['Santa Cruz', 37.3855, -5.9906, 800], ['Calle Sierpes', 37.3900, -5.9945, 800],
  ['Triana', 37.3834, -6.0030, 1000], ['La Macarena', 37.4012, -5.9895, 1000], ['La Alameda', 37.4005, -5.9930, 800],
  ['Nervión', 37.3825, -5.9707, 1200], ['Los Remedios', 37.3750, -6.0060, 1200], ['Dos Hermanas', 37.2830, -5.9210, 1800],
  ['Alcalá de Guadaíra', 37.3380, -5.8410, 1800], ['Mairena del Aljarafe', 37.3450, -6.0600, 1800], ['Camas', 37.4020, -6.0320, 1500]];
const MIN_RATING = 3.8, MIN_REVIEWS = 30;

async function nearby(type, [name, lat, lng, radius]) {
  const r = await fetch('https://places.googleapis.com/v1/places:searchNearby', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Goog-Api-Key': KEY, 'X-Goog-FieldMask': A.FIELD_MASK },
    body: JSON.stringify({ includedTypes: [type], maxResultCount: 20, rankPreference: 'POPULARITY', languageCode: 'es', regionCode: 'ES',
      locationRestriction: { circle: { center: { latitude: lat, longitude: lng }, radius } } })
  });
  if (!r.ok) throw new Error(name + ' ' + type + ': ' + r.status + ' ' + await r.text());
  return ((await r.json()).places || []).map(p => ({ p, zone: name }));
}

const found = new Map();
for (const z of ZONES) for (const t of ['bar', 'restaurant']) {
  try { for (const { p, zone } of await nearby(t, z)) {
    if (p.businessStatus && p.businessStatus !== 'OPERATIONAL') continue;
    if ((p.rating || 0) < MIN_RATING || (p.userRatingCount || 0) < MIN_REVIEWS) continue;
    if (!found.has(p.id)) found.set(p.id, { ...A.fromPlace(p), zone });
  } } catch (e) { console.error(e.message); }
  console.error('✓', z[0], t, '->', found.size);
}
const bars = [...found.values()].sort((a, b) => b.rating * Math.log10(b.n + 10) - a.rating * Math.log10(a.n + 10));
writeFileSync(new URL('../data/bars.js', import.meta.url),
  '/* Generado por tools/analyze.mjs el ' + new Date().toISOString() + ' */\nwindow.TB_DATA = ' + JSON.stringify({ source: 'google', generated: new Date().toISOString(), bars }, null, 1) + ';\n');
console.error('Escritos', bars.length, 'bares en data/bars.js');
