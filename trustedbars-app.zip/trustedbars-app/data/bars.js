/* Bares de DEMOSTRACIÓN (ficticios) de Sevilla y alrededores.
   tools/analyze.mjs sobrescribe este archivo con bares reales de Google Places. */
(function () {
  const meal = {
    A: [['Tapa de carrillada', 4, 1], ['Tapa de croquetas', 3.5, 1], ['Media de ensaladilla (a compartir entre 2)', 5, .5], ['Caña', 2.5, 1]],
    B: [['Montadito de pringá', 2.2, 1], ['Espinacas con garbanzos', 2.5, 1], ['Tortilla de patata', 2.5, 1], ['Caña', 1.8, 1]],
    C: [['Bocadillo de calamares', 5.5, 1], ['Bravas a medias', 5, .5], ['Caña', 2.5, 1], ['Café', 1.5, 1]],
    D: [['Tapa de salmorejo', 3.5, 1], ['Tapa de pollo al ajillo', 4, 1], ['Media de croquetas (a compartir entre 2)', 5.5, .5], ['Tinto', 2.5, 1]],
    E: [['Pincho de tortilla', 2.8, 1], ['Media de espinacas con garbanzos (entre 2)', 5, .5], ['Montadito de lomo', 3, 1], ['Tinto de verano', 2.5, 1]],
    F: [['Pescaíto frito (ración entre 3)', 12, 1 / 3], ['Tapa de salmorejo', 3.5, 1], ['Caña', 2.5, 1], ['Pan y aliños', .8, 1]],
    G: [['Media de presa ibérica (entre 2)', 9, .5], ['Tapa de croquetas', 3.5, 1], ['Tapa de ensaladilla', 3.5, 1], ['Caña', 2.5, 1], ['Postre', 3.5, 1]],
    H: [['Tapa de cola de toro', 4.5, 1], ['Huevos rotos (media, entre 2)', 9, .5], ['Caña', 2.5, 1], ['Café', 1.6, 1]],
    I: [['Chicharrones (ración entre 3)', 9, 1 / 3], ['Tapa de carne con tomate', 3.2, 1], ['Tapa de albóndigas', 3.2, 1], ['Caña', 2.2, 1]],
    J: [['Gambas al ajillo (media, entre 2)', 10, .5], ['Tapa de lomo al whisky', 3.5, 1], ['Caña', 2.3, 1], ['Pan', .7, 1]],
    K: [['Hamburguesa de ibérico', 8.5, 1], ['Patatas a compartir', 4, .5], ['Cerveza', 3, 1]],
    L: [['Tapa de arroz con costillas', 4, 1], ['Tapa de calamares', 3.8, 1], ['Tapa de espinacas', 2.6, 1], ['Caña', 2, 1]]
  };
  const K1 = [[780, 960], [1200, 1410]];
  const h = (wl, ww, el, ew) => ({ week: { level: wl, waitMin: ww, estimated: true }, weekend: { level: el, waitMin: ew, estimated: true } });
  const n = (src, age, waitMin, cover, vibe, informant) => src === 'local'
    ? { src, informant: informant || 'local', age, waitMin, maxGroup: cover, vibe }
    : { src, informant: informant || 'c' + age, age, waitMin, groupSize: cover, vibe };
  function bar(id, name, zone, ll, rating, cnt, praised, groupMax, wk, we, m, hab, kitchen, notices, k) {
    return { id, source: 'demo', name, zone, ll, rating, n: cnt, praised, groupMax, price: { week: wk, weekend: we }, priceDoc: true,
      priceSource: 'Carta de demostración', menuDate: '10/11/2026', meal: meal[m], habitual: hab, kitchen: { week: kitchen, weekend: kitchen },
      phone: '+34 600 000 0' + String(k).padStart(2, '0'), addr: 'Calle de Ejemplo ' + (10 + k * 3) + ' (dirección ficticia), ' + zone,
      notices };
  }
  window.TB_DATA = { source: 'demo', generated: '2026-11-22', bars: [
    bar('sev-A', 'Bar del Patio', 'Plaza de la Alfalfa', [37.39586, -5.98792], 4.6, 812, 'La carrillada y las croquetas, muy recomendadas en las reseñas', 6, [12, 14], [13, 15], 'A', h('baja', 5, 'media', 10), [[780, 960], [1200, 1410]], [n('local', 4, 0, 6, 'tranquilo')], 1),
    bar('sev-B', 'Taberna La Revuelta', 'Plaza de la Alfalfa', [37.39137, -5.98921], 4.3, 1240, 'El montadito de pringá, muy citado en las reseñas', 8, [9, 9], [10, 10], 'B', h('media', 15, 'alta', 25), [[780, 960], [1200, 1425]], [n('cliente', 6, 25, 4, 'animado')], 2),
    bar('sev-C', 'Casa Mareo', 'Plaza de la Alfalfa', [37.39178, -5.99583], 4.5, 530, 'Los calamares, la tapa más repetida en las opiniones', 4, [11, 14], [12, 15], 'C', h('media', 10, 'alta', 15), [[1140, 1440]], [n('local', 3, 0, 4, 'lleno')], 3),
    bar('sev-D', 'Tapería El Arco', 'Plaza de la Alfalfa', [37.39629, -5.99373], 4.4, 390, 'El pollo al ajillo, muy elogiado en las opiniones', 4, [12, 13], [13, 14], 'D', h('baja', 5, 'media', 10), [[780, 960], [1230, 1380]], [n('local', 62, 0, 4, 'tranquilo')], 4),
    bar('sev-E', 'Taberna Ribera Vieja', 'Triana', [37.3840, -6.0020], 4.5, 960, 'El montadito de lomo, de lo más pedido', 6, [10, 12], [11, 13], 'E', h('media', 8, 'alta', 20), K1, [n('local', 7, 5, 6, 'animado')], 5),
    bar('sev-F', 'Bar Muralla Norte', 'La Macarena', [37.4020, -5.9880], 4.4, 720, 'El pescaíto frito, muy elogiado en las reseñas', 8, [10, 12], [11, 13], 'F', h('baja', 0, 'media', 10), K1, [n('cliente', 9, 0, 2, 'tranquilo')], 6),
    bar('sev-G', 'Casa Judería Alta', 'Santa Cruz', [37.3860, -5.9895], 4.7, 2100, 'La presa ibérica, citada en casi todas las reseñas', 8, [17, 19], [18, 21], 'G', h('alta', 15, 'alta', 25), K1, [n('local', 2, 0, 8, 'tranquilo')], 7),
    bar('sev-H', 'Bar Cartuja Nueva', 'Nervión', [37.3830, -5.9690], 4.2, 410, 'La cola de toro, recomendada con frecuencia', 6, [13, 15], [14, 16], 'H', h('baja', 0, 'media', 8), K1, [], 8),
    bar('sev-I', 'Tasca Los Naranjos', 'Dos Hermanas', [37.2835, -5.9205], 4.5, 640, 'Los chicharrones y la carne con tomate', 10, [11, 13], [12, 14], 'I', h('media', 8, 'alta', 15), K1, [n('cliente', 12, 10, 4, 'animado')], 9),
    bar('sev-J', 'Mesón Castillo Chico', 'Alcalá de Guadaíra', [37.3375, -5.8415], 4.4, 350, 'Las gambas al ajillo, siempre citadas', 8, [11, 13], [12, 14], 'J', h('baja', 0, 'media', 10), K1, [n('local', 5, 0, 6, 'tranquilo')], 10),
    bar('sev-K', 'Gastrobar Olivar', 'Mairena del Aljarafe', [37.3455, -6.0605], 4.1, 280, 'La hamburguesa de ibérico', 6, [13, 15], [14, 17], 'K', h('media', 5, 'alta', 15), K1, [], 11),
    bar('sev-L', 'Tapería La Cornisa', 'Camas', [37.4025, -6.0325], 4.6, 450, 'El arroz con costillas, muy elogiado', 6, [12, 14], [13, 15], 'L', h('baja', 0, 'media', 8), K1, [n('cliente', 3, 0, 4, 'tranquilo')], 12)
  ] };
})();
