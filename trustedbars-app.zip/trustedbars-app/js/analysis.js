/* Análisis compartido por la app y por tools/analyze.mjs.
   Convierte un lugar de Google Places API (New) en un bar de TrustedBars con:
   precio por persona (entre semana / fin de semana), afluencia habitual estimada,
   tamaño de grupo cómodo y horario de cocina aproximado.
   Importante: Google NO ofrece "horas punta" por API. La afluencia habitual es una
   ESTIMACIÓN a partir de nº de reseñas, valoración y tipo de local. Se marca como tal. */
(function (root) {
  const PRICE_LEVEL = {
    PRICE_LEVEL_FREE: [0, 5], PRICE_LEVEL_INEXPENSIVE: [8, 12], PRICE_LEVEL_MODERATE: [12, 22],
    PRICE_LEVEL_EXPENSIVE: [22, 38], PRICE_LEVEL_VERY_EXPENSIVE: [40, 80]
  };
  const money = m => (m ? Number(m.units || 0) + (m.nanos || 0) / 1e9 : null);
  const WEEKEND_PRICE_FACTOR = 1.08; // supuesto: cartas y consumo suben algo en fin de semana

  function crowd(n, rating, day) {
    let s = Math.log10(Math.max(10, n || 10)) * 25;        // 25 (10 reseñas) … 100 (10.000)
    if (rating >= 4.5) s *= 1.05;
    if (day === 'weekend') s *= 1.25;
    const level = s >= 80 ? 'alta' : s >= 60 ? 'media' : 'baja';
    const waitMin = level === 'alta' ? (day === 'weekend' ? 20 : 15) : level === 'media' ? (day === 'weekend' ? 12 : 8) : (day === 'weekend' ? 5 : 0);
    return { level, waitMin, estimated: true };
  }

  function kitchen(place, day) {
    const target = day === 'weekend' ? 6 : 3;               // sábado / miércoles (0 = domingo)
    const periods = (place.regularOpeningHours && place.regularOpeningHours.periods) || [];
    const w = [];
    periods.forEach(p => {
      if (!p.open || p.open.day !== target || !p.close) return;
      const a = (p.open.hour || 0) * 60 + (p.open.minute || 0);
      let c = (p.close.hour || 0) * 60 + (p.close.minute || 0);
      if (p.close.day !== p.open.day) c += 1440;
      w.push([a, c]);
    });
    return w.length ? w : [[780, 960], [1200, 1410]];
  }

  function fromPlace(place) {
    const name = (place.displayName && place.displayName.text) || 'Sin nombre';
    const pr = place.priceRange, s = pr && money(pr.startPrice), e = pr && money(pr.endPrice);
    let base, doc;
    if (s != null && e != null) { base = [Math.round(s), Math.round(e)]; doc = true; }
    else if (s != null) { base = [Math.round(s), Math.round(s) + 5]; doc = true; }
    else { base = PRICE_LEVEL[place.priceLevel] || [10, 20]; doc = false; }
    const we = base.map(x => Math.round(x * WEEKEND_PRICE_FACTOR));
    const types = place.types || [];
    const rating = place.rating || 0, n = place.userRatingCount || 0;
    return {
      id: 'g-' + place.id, source: 'google', placeId: place.id, name,
      zone: '', ll: [place.location.latitude, place.location.longitude],
      addr: place.formattedAddress || '', phone: place.nationalPhoneNumber || '', mapsUri: place.googleMapsUri || '',
      rating, n,
      praised: n ? 'Valorado con ' + String(rating).replace('.', ',') + ' en ' + n + ' reseñas de Google' : 'Sin reseñas suficientes',
      groupMax: types.includes('restaurant') ? 8 : 5,
      price: { week: base, weekend: we }, priceDoc: doc, priceSource: doc ? 'Google (rango de precio por persona)' : 'Estimado a partir del nivel de precio de Google',
      menuDate: null, meal: [],
      habitual: { week: crowd(n, rating, 'week'), weekend: crowd(n, rating, 'weekend') },
      kitchen: { week: kitchen(place, 'week'), weekend: kitchen(place, 'weekend') },
      notices: []
    };
  }
  const api = { fromPlace, crowd, WEEKEND_PRICE_FACTOR, FIELD_MASK: [
    'places.id', 'places.displayName', 'places.location', 'places.rating', 'places.userRatingCount', 'places.priceLevel',
    'places.priceRange', 'places.regularOpeningHours', 'places.nationalPhoneNumber', 'places.formattedAddress',
    'places.googleMapsUri', 'places.types', 'places.businessStatus'].join(',') };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.TBAnalysis = api;
})(typeof self !== 'undefined' ? self : this);
